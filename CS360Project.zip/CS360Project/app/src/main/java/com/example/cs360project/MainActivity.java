package com.example.cs360project;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText userNameText, passWordText;
    private UserDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new UserDatabase(this);

        // initializing all variables
        userNameText = findViewById(R.id.editUsernameText);
        passWordText = findViewById(R.id.editPasswordText);
        Button loginBtn = findViewById(R.id.buttonLogin);
        Button registerUserBtn = findViewById(R.id.buttonCreateUser);

        registerUserBtn.setOnClickListener(view -> {

            String userName = userNameText.getText().toString();
            String passWord = passWordText.getText().toString();

            if (userName.isEmpty() && passWord.isEmpty()) {
                Toast.makeText(MainActivity.this,"Please enter all data..", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean checkUserPass = db.checkUserCredentials(userName,passWord);
            if (!checkUserPass) {
                db.addNewUser(userName,passWord);
                Toast.makeText(MainActivity.this,"Registered User Successful", Toast.LENGTH_SHORT).show();
            }
        });

        loginBtn.setOnClickListener(view -> {
            String userName = userNameText.getText().toString();
            String passWord = passWordText.getText().toString();

            boolean checkUserPass = db.checkUserCredentials(userName, passWord);
            if (checkUserPass) {
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                setContentView(R.layout.database_activity);
            }
        });
    }
}
