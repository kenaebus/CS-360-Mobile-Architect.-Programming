package com.example.cs360project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    ItemDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_activity);

        // initializing all variables
        Button addItemBttn = findViewById(R.id.addItemBttn);
        Button logOutBttn = findViewById(R.id.logOutBttn);

        //Initialize database
        db = new ItemDatabase(this);


        addItemBttn.setOnClickListener(view -> {
            setContentView(R.layout.add_item_activity);

            EditText addName = findViewById(R.id.addProductName);
            EditText addDesc = findViewById(R.id.addProductDesc);
            EditText addQuantity = findViewById(R.id.addQuantityNumber);
            Button saveItemBttn = findViewById(R.id.saveItemBttn);


            saveItemBttn.setOnClickListener(view1 -> {
                String addNameStr = addName.getText().toString();
                int addQuantityStr =  Integer.parseInt(String.valueOf(addQuantity.getText()));
                String addDescStr = addDesc.getText().toString();

                if (addNameStr.isEmpty() && (addQuantityStr == -1)) {
                    Toast.makeText(InventoryActivity.this,"Please enter all data..", Toast.LENGTH_SHORT).show();
                } else {
                    db.addNewItem(addNameStr,addDescStr,addQuantityStr);
                    Toast.makeText(InventoryActivity.this,"Added Item Successfully", Toast.LENGTH_SHORT).show();
                }
            });


        });

        logOutBttn.setOnClickListener(view -> {
            setContentView(R.layout.activity_main);
            finish();
        });




    }
}
