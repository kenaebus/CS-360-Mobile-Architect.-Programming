package com.example.cs360project;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class ItemDatabase extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "items.db";
    private static final int VERSION = 1;


    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable {
        private static final String TABLE_NAME = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "product name";
        private static final String COL_DESC = "product description";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate( SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + ItemTable.TABLE_NAME + " (" +
                ItemTable.COL_ID + " INTEGER primary key autoincrement, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_DESC + " text," +
                ItemTable.COL_QUANTITY + "INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + ItemTable.TABLE_NAME);
        onCreate(db);
    }

    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + ItemTable.TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(ItemTable.COL_ID));
                String name = cursor.getString(cursor.getColumnIndex(ItemTable.COL_NAME));
                String description = cursor.getString(cursor.getColumnIndex(ItemTable.COL_DESC));
                int quantity = cursor.getInt(cursor.getColumnIndex(ItemTable.COL_QUANTITY));

                itemList.add(new Item(id, name, description, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }

    public Integer deleteItem(Integer productId, String productName, String productDesc, Integer quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(ItemTable.TABLE_NAME, "ID = ?", new String[]{String.valueOf(productId)});
    }

    public void addNewItem(String productName, String productDesc, Integer quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues data = new ContentValues();

        data.put(ItemTable.COL_NAME,productName);
        data.put(ItemTable.COL_DESC,productDesc);
        data.put(ItemTable.COL_QUANTITY,quantity);

        db.insert(ItemTable.TABLE_NAME,null,data);
        db.close();
    }
}
